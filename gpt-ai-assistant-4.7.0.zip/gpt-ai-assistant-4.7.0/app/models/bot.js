class Bot {
  isActivated;

  constructor({
    isActivated,
  }) {
    this.isActivated = isActivated;
  }
}

export default Bot;
