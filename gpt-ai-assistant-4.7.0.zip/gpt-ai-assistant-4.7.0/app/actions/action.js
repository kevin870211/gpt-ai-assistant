class Action {
  type;
}

export default Action;
