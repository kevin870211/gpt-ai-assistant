export const TYPE_SUM = 'sum';
export const TYPE_ANALYZE = 'analyze';
export const TYPE_SYSTEM = 'system';
export const TYPE_TRANSLATE = 'translate';
