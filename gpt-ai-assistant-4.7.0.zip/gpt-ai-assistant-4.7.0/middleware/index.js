import validateLineSignature from './validate-line-signature.js';

export {
  validateLineSignature,
};

export default null;
